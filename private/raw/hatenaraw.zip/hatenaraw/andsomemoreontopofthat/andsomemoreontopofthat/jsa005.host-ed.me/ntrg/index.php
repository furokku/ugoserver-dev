<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=240">
<title>Back soon! | Nintrigue</title>
<link rel="stylesheet" href="http://jsa005.host-ed.me/ntrg/as/st/dsi.css" type="text/css">
<link rel="icon" href="http://jsa005.host-ed.me/ntrg/as/im/favicon.ico">
</head>
<body>
<span class="header font-big">
<span class="header-image">&nbsp;</span>
<span class="title font-med" style="display:block;padding:0px;margin:0px;margin-left:-16px;text-align:center;word-wrap:break-word;width:240px;">Back soon!</span>
</span>
<span class="bar"><img class="bar-avatar" src="http://www.gravatar.com/avatar/00000000000000000000000000000000?s=32&d=mysteryman">
<span class="bar-content"><span class="comic font-med">Nintrigue (<a href="/ntrg/account/login-form.php">Login</a>)</span>
<br>
<a href="/ntrg/">Home</a> &brvbar; <a href="/ntrg/map/">Maps</a>
</span></span>
<span class="body-content">
<span class="font-med comic" style="text-align:center;">Hey there!</span>
<br>
The JSiVi you know and love, with its innovations programmed with human hands and great passion, is being reborn as <span class="comic" style="color:#00BFFF;">Nintrigue</span>. And we know you'll love it. With an all new style, more epic features and the same human touch and creativity, Nintrigue is going to be even better. And it was hard to top JSiVi. But we did it. So, explore Nintrigue in the making, and try <a href="map">Nintrigue Maps</a>, which is functioning, and bask in the glory of the new design. See ya later. ;)
</span>
<span class="footer"><span class="footer-content">&copy; Nintrigue 2013. <span class="float-right"><a href="terms.php">Terms</a> | <a href="credits.php">Credits</a></span></span>
</body>
</html>
